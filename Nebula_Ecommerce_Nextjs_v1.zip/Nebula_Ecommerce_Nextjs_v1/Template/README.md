# Nebula E-commerce Theme

Thank you for purchasing this template!

## Getting Started
1. Open this folder in your terminal.
2. Run `npm install`.
3. Run `npm run dev`.

Please check the `Documentation` folder for the full guide.